function [Z, ANC] = PRSA(x, L, CUT)

% the anchor point: i means x_{i}-x_{i-1} > 0
ANC = find(diff(x)>CUT) + 1 ;

% ANCplot is for the final plotting
disp(length(ANC))

% avoid the boundary effect
ANC(ANC>length(x)-L) = [] ;
ANC(ANC<=L) = [] ;

Zn0 = zeros(2*L+1, 1) ;

for jj = 1:length(ANC)
    Zn0 = Zn0 + x(ANC(jj)-L: ANC(jj)+L) ;
end

% Zn is the output of PRSA
Z = Zn0 / length(ANC) ;