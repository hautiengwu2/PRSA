clear ; close all

scrsz = get(0,'ScreenSize');
h1 = figure('Position',[1 scrsz(4) scrsz(3)*3/4 scrsz(4)]) ;


n = 8e6 ;
L = 100 ;
Clist = linspace(-3, 3, 3) ;

RP = {'white noise', 'ARMA(2,1)', 'ARMA(2,1)', 'ARMA(4,2)', 'BM'} ;


for RPidx = 1: 4

    % run PRSA with different c
    Zn = zeros(2*L+1, length(Clist)) ;


    for pp = 1: length(Clist)

        CUT = Clist(pp) ;


        if RPidx == 1
            x = randn(n,1) ;
            [ACVF, sigma_Y] = acf(0, 0, L+1, 1) ;
            C = sigma_Y * ACVF ;

            % genZeta.m generate the theoretical result
            if pp == 2 ; JZn = genZeta(C, CUT) ; end
        elseif RPidx == 2
            x = armaxfilter_simulate(n, .0, 2, [0.01 .15], 1, -.15) ; %ARMA(2,1), type1
            [ACVF, sigma_Y] = acf([0.01 .15], -.15, L+1, 1) ;
            C = sigma_Y * ACVF ;
            if pp == 2 ; JZn = genZeta(C, CUT) ; end
        elseif RPidx == 3
            x = armaxfilter_simulate(n, .0, 2, [0.1 -.85], 1, .5) ; %ARMA(2,1), type2
            [ACVF, sigma_Y] = acf([0.1 -.85], .5, L+1, 1) ;
            C = sigma_Y * ACVF ;
            if pp == 2 ; JZn = genZeta(C, CUT) ; end
        elseif RPidx == 4
            x = armaxfilter_simulate(n, .0, 4, [0.01 0.01 0 -.9], 2, [0.2 -.5]) ; %ARMA(4,2)
            [ACVF, sigma_Y] = acf([0.01 0.01 0 -.9], [0.2 -.5], L+1, 1) ;
            C = sigma_Y * ACVF ;
            if pp == 2 ; JZn = genZeta(C, CUT) ; end
        end


        [Z, ANC] = PRSA(x, L, CUT) ;
        if CUT == 0
            ANCplot = ANC ;
        end
        Zn(:, pp) = Z ;

    end


    
    
    clear ANS Zn0

    figure(h1)
    subplot_tight(5, 6, (RPidx-1)*6+[2 3], [0.03 0.033])
    plot(1:length(x), x, 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
    plot(ANCplot, x(ANCplot), 'ro', 'linewidth', 3) ;
    axis tight ; axis([1000 1100 min(x(1000:1100)) max(x(1000:1100))*1.35])
    text(1000.5, max(x(1000:1100))*1.2, RP{RPidx}, 'Interpreter', 'latex', 'fontsize', 18);
    set(gca, 'fontsize', 16)

    if RPidx < 4
        set(gca, 'xtick', []) ;
    elseif RPidx == 4
        xlabel('sample index') ;
    end

    subplot_tight(5, 6, (RPidx-1)*6+[4 5], [0.03 0.033])
    plot(-L:L, JZn, 'r', 'linewidth', 3) ; hold on ; 
    plot(-L:L, Zn(:, 2), 'color', [0 0 0] + 2/(length(Clist)+1), 'linewidth', 2) ;
    plot([0 0], [-1 1]*max(abs(Zn(:))), 'b--', 'linewidth', 1) ;
    axis tight ; set(gca, 'fontsize', 16) ; xlim([-70 70])


    if RPidx < 4
        set(gca, 'xtick', []) ;
    elseif RPidx == 4
        xlabel('sample index') ;
    end


    subplot_tight(5, 6, (RPidx-1)*6+6, [0.03 0.033])
    for pp = 1: length(Clist)
        plot(-L:L, Zn(:, pp), 'color', [0 0 0] + pp/(length(Clist)+2), 'linewidth', 2) ;
        hold on ;
    end

    plot([0 0], [-1 1]*max(abs(Zn(:))), 'b--', 'linewidth', 1) ;
    axis tight ; set(gca, 'fontsize', 16) ; xlim([-10 10])


    if RPidx < 4
        set(gca, 'xtick', []) ;
    elseif RPidx == 4
        xlabel('sample index') ;
    end

end


exportgraphics(h1, 'Figure2.pdf', 'ContentType', 'vector', 'BackgroundColor','none');



function JZn = genZeta(C, CUT)
% generate theoretical result.

L = length(C) - 2 ;
JZn = zeros(L, 1) ;
for ll = -L: L
    % C(j) = covariance of step j-1
    if ll >= 0
        Q1 = (C(ll+1) - C(ll+2)) ./ sqrt( 4 * pi * (C(1)-C(2)) ) ;
    else
        Q1 = (C(-ll+1) - C(-ll)) ./ sqrt( 4 * pi * (C(1)-C(2)) ) ;
    end
    Q2 = exp(-CUT^2 / (4 * (C(1)-C(2)))) ;
    Q3 = 1./(1-normcdf(CUT/sqrt(2 * (C(1)-C(2))))) ;
    JZn(L+1+ll) = Q1 * Q2 * Q3 ;
end

end