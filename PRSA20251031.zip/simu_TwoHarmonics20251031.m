clear ; close all
scrsz = get(0,'ScreenSize');

n = 8e6 ;
CUTlist = linspace(-0.8, 0.8, 5) ;


fs = 10 ;
time = (-n/2:n/2)' / fs ;
L = 1000 ; % 2*L/fs = 200 s in total


xi = linspace(0.2, 0.9, 5) ;
A = linspace(0.7, 2, 5) ;



phi = 2*pi*rand(size(xi)) ;


for RPidx = 1: length(xi)

    h1 = figure('Position',[1 scrsz(4) scrsz(3) scrsz(4)]) ;

    Zn = zeros(2*L+1, length(CUTlist)) ;

    for Cidx = 1: length(CUTlist)

        CUT = CUTlist(Cidx) ;

        HF = sin(2*pi*time) ;
        LF = A(RPidx)*sin(2*pi*xi(RPidx)*time+phi(RPidx)) ;
        x = HF + LF ;


        % run PRSA
        % the anchor point: i means x_{i}-x_{i-1} > 0
        
        [Z, ANC] = PRSA(x, L, CUT*max(diff(x))) ;
        Zn(:, Cidx) = Z ;

        
        % prepare theoretical result for CUT=0
        if CUT == 0
            utic = linspace(0, min(1, 1/A(RPidx)/xi(RPidx)), 10000) ;
            du = median(diff(utic)) ;

            % ignore the last point to avoid /0 case
            utic = utic(1:end-1) ;
            Xintegrand = sqrt( (1-A(RPidx)^2*xi(RPidx)^2 * utic.^2) ./ (1-utic.^2) ) ;
            idx = ~isnan(Xintegrand) ;
            B1 = (4 / (pi^2)) * du * sum( Xintegrand(idx) ) ;

            Yintegrand = sqrt( (1-utic.^2) ./ (1-A(RPidx).^2 *xi(RPidx).^2 * utic.^2) ) ;
            idx = ~isnan(Yintegrand) ;
            B2 = (4*A(RPidx).^2*xi(RPidx) / (pi^2)) * du * sum( Yintegrand(idx) ) ;

            sss = ((-L:L)+0.5) / fs ;
            JZn = B1 * sin(2*pi*sss) + B2 * sin(2*pi*xi(RPidx)*sss) ;

            disp([B1 B2])

        else

            JZn = nan(size(Zn)) ;

        end


        subplot_tight(6, 6, (Cidx-1)*6+[2 3], [0.03 0.033])
        plot(time, x, 'color', [.7 .7 .7], 'linewidth', 2) ; hold on ;
        plot(time(ANC), x(ANC), 'ro', 'linewidth', 3) ;
        axis tight ; axis([100 120 -inf max(x)*1.38])
        text(100.5, max(x)*1.2,...
            ['$A = ' num2str(0.01*round(100*A(RPidx))) ',\ \xi = ' num2str(0.01*round(100*xi(RPidx))) '$'], ...
            'Interpreter', 'latex', 'fontsize', 18);
        set(gca, 'fontsize', 16) ; 
        ylabel(['c = ' num2str(round(1000*CUT*max(diff(x)))/1000)]) ;

        if Cidx < 5
            set(gca, 'xtick', []) ;
        elseif Cidx == 5
            xlabel('Time (sec)') ;
        end

        subplot_tight(6, 6, (Cidx-1)*6+[4 5], [0.03 0.033])
        if CUT == 0
            plot((-L:L)/fs, JZn, 'r', 'linewidth', 4) ; hold on ;
        end
        %plot((-L:L)/fs, HF(n/2+1+(-L:L)), 'color', [.7 .7 .7], 'linewidth', 2) ;
        plot((-L:L)/fs, Zn(:, Cidx), 'k', 'linewidth', 2) ; hold on ;
        plot([0 0], [-1 1]*max(abs(Zn(:, Cidx))), 'b', 'linewidth', 3) ;
        axis tight ; set(gca, 'fontsize', 16) ; xlim([-5 5])

       
        if Cidx < 5
            set(gca, 'xtick', []) ;
        elseif Cidx == 5
            xlabel('Time (sec)') ;
        end



        subplot_tight(6, 6, (Cidx-1)*6+6, [0.03 0.033])
        zhat = fft(Zn(:, Cidx)) ;
        xitic = fs * (1: L) / (2*L+1) ;
        bar(xitic, abs(zhat(2:L+1)), 'k') ;
        axis tight ; set(gca, 'fontsize', 16) ; xlim([0 1.1])

        if Cidx < 5
            set(gca, 'xtick', []) ;
        elseif Cidx == 5
            xlabel('Freq (Hz)') ;
        end

    end


    exportgraphics(h1, ['Figure' num2str(RPidx) '.pdf'], 'ContentType',...
        'vector', 'BackgroundColor','none') ;

    close all ;

end